# CatchaThief

Take a picture of whoever inputs an incorrect passcode!
Does not support Touch ID/Face ID yet.
Images are stored in /var/mobile/catchathief.
Sending images via email is being looked into.

Credits to Lucas Jackson (neoneggplant) for the photo shooter
